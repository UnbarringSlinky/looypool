var searchData=
[
  ['inode_5ffailure',['INODE_FAILURE',['../inodedef_8h.html#a01d6160e32baf34fc2183aff35c917b6',1,'inodedef.h']]],
  ['inode_5fsuccess',['INODE_SUCCESS',['../inodedef_8h.html#a6ab4716428c2bdc69702df81852e055b',1,'inodedef.h']]]
];
