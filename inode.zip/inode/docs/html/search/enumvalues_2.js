var searchData=
[
  ['inode_5fcorrupt',['INODE_CORRUPT',['../inodetdfs_8h.html#abc6126af1d45847bc59afa0aa3216b04a7297644c9cdf6520723ffd6aa029ae97',1,'inodetdfs.h']]],
  ['inode_5ffix',['INODE_FIX',['../inodetdfs_8h.html#abc6126af1d45847bc59afa0aa3216b04a072d2cd58191d51f0faebaeb9db3bf7e',1,'inodetdfs.h']]]
];
