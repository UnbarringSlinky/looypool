var searchData=
[
  ['rec_5fname_5fprefix',['REC_NAME_PREFIX',['../inodedef_8h.html#a22f091dfb43508b0274af4c84e658b7c',1,'inodedef.h']]],
  ['root_5finode',['ROOT_INODE',['../inodedef_8h.html#a6fefb99a279054362ece826744775d7d',1,'inodedef.h']]]
];
