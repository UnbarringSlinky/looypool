var searchData=
[
  ['boot_5fsector_5foffset',['BOOT_SECTOR_OFFSET',['../inodedef_8h.html#ae3d6ffb7ce73b92de2e4c01ae5226958',1,'inodedef.h']]],
  ['byte',['BYTE',['../inodedef_8h.html#aec93e83855ac17c3c25c55c37ca186dd',1,'inodedef.h']]]
];
