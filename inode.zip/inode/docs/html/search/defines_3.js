var searchData=
[
  ['get_5fblock_5foffset_5ffrom_5fbyte_5foffset',['GET_BLOCK_OFFSET_FROM_BYTE_OFFSET',['../inodedef_8h.html#af1b4af3d72bf7a539e20e4b3ce13b6d8',1,'inodedef.h']]]
];
